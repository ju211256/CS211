#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {

  // Open the filename given as the first command line argument for reading
  FILE* fp = fopen(argv[1], "r");
  if (!fp) {
    perror("fopen failed");
    return EXIT_FAILURE;
  }

  char buf[256];

  char* string = fgets(buf, 256, fp);
  int square = atoi(string);

  int root = sqrt( square );

  double real_root = sqrt(square);

  int rounded_root = floor(real_root);

  if (real_root - rounded_root > 0)
  {
    printf("square root not integer\n");
  }

  if ( root*root == square ) {

    // Printing in C.
    // %d is the format specifier for integer numbers.
    // \n is the newline character
    printf( "%d\n", root );
    return EXIT_SUCCESS;    

  } else {

    printf("square root not integer\n");

  }

}