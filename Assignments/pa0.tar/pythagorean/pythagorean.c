#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {

  // Open the filename given as the first command line argument for reading
  FILE* fp = fopen(argv[1], "r");
  if (!fp) {
    perror("fopen failed");
    return EXIT_FAILURE;
  }

  char first[256];
  char second[256];

  char* x = fgets(first, 256, fp);
  int a = atoi(x);

  char* y = fgets(second, 256, fp);
  int b = atoi(y);

  int c_sq = fmax(a*a, b*b) - fmin(a*a, b*b);

  double real_root = sqrt(c_sq);

  int rounded_root = floor(real_root);

  if (real_root - rounded_root == 0)
  {
    printf( "%d\n", (int) real_root);
    return EXIT_SUCCESS;    
  } else if ( sqrt(a*a + b*b) - floor(sqrt(a*a + b*b)) == 0)
  {
    printf( "%d\n", (int) sqrt(a*a + b*b));
    return EXIT_SUCCESS;
  } else
  {
    printf( "-1\n");
  }

}
