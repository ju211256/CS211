#include "../graphutils.h" // header for functions to load and free adjacencyList
#include "../queue/queue.h" // header for queue

int main ( int argc, char* argv[] ) {

    // First, read the query file to get the source and target nodes in the maze
    FILE* fp = fopen(argv[2], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    size_t source, target;
    size_t query[2];

    for (int i = 0; i < 2; i++)
    {
        fscanf(fp, "%lu", &query[i]);
    }
    
    fclose(fp);

    source = query[0];
    target = query[1];

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;

    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);

    // An array that keeps track of who is the parent node of each graph node we visit
    graphNode_t* parents = calloc(graphNodeCount, sizeof(graphNode_t));
    for (size_t i=0; i<graphNodeCount; i++) 
    {
        parents[i] = -1; // -1 indicates that a nodes is not yet visited
    }

    parents[source] = source;

    // USE A QUEUE TO PERFORM BFS
    Queue queue = { .front=NULL, .back=NULL };

    enqueue(&queue, &adjacencyList[source]);

    while(queue.front != NULL)
    {
        AdjacencyListNode* temp = dequeue(&queue);
        int current = temp->graphNode;

        if (current == target)
        {
            break;
        }

        // so long as we haven't found the target node yet, iterate through the adjacency list
        // add each neighbor that has not been visited yet (has no parents) to the queue of nodes to visit

        AdjacencyListNode* neighbor = adjacencyList[current].next;

        while (neighbor != NULL)
        {
            if(neighbor->graphNode == target)
            {
                parents[neighbor->graphNode] = current;
                break;
            }

            if(parents[neighbor->graphNode] == -1)
            {
                parents[neighbor->graphNode] = current;
                enqueue(&queue, neighbor);
            }

            // Visit the next node at the front of the queue of nodes to visit
            neighbor = neighbor->next;

        }
    }

    // Now that we've found the target graph node, use the parent array to print maze solution
    // Print the sequence of edges that takes us from the source to the target node
    int* tracker = calloc(graphNodeCount, sizeof(int));
    int trackerLength = 0;
    int searcher = target;

    while (searcher != source) 
    {
        tracker[trackerLength++] = searcher;
        searcher = parents[searcher];
    }

    tracker[trackerLength++] = source;

    for (int i = trackerLength-1; i>0; i--) 
    {
        printf("%d %d\n", tracker[i], tracker[i-1]);
    }

    // free any queued graph nodes that we never visited because we already solved the maze
    while ( queue.front ) {
        dequeue(&queue);
    }

    free(tracker);
    free (parents);
    freeAdjList ( graphNodeCount, adjacencyList );

    return EXIT_SUCCESS;
}
