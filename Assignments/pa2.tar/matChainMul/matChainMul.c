#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include "../matMul/matMul.h"

int** makearray(int length, int width)
{
    int** product = calloc( length, sizeof(int*) );
    for ( unsigned int i=0; i < length; i++ ) 
    {
        product[i] = calloc( width, sizeof(int) );
    }

    for (int i = 0; i < length; i++)
    {
        for (int j = 0; j < width; j++)
        {
            product[i][j] = -1;
        }
    }

    return product;
}

void freearray(int length, int** array2d)
{
    for ( unsigned int i=0; i<length; i++ ) 
    {
        free( array2d[i] );
    }
    free( array2d );
}

void multiply
(   unsigned int matrixCount,   
    unsigned int* rowSizes,
    unsigned int* colSizes,
    int*** matrices, 
    int** solutions, 
    int** results, // malloced before calling recursive function
    int tracker //keeps track of current matrix (matrices) it is on
)
{
    //check both splits if they are single matrices or not
    //if they are single matrix by themseleves, leave them alone
    //if there are more than one matrix in the chain, continue splitting
    if (matrixCount == 1)
    {
        for (int i = 0; i < rowSizes[tracker]; i++)
        {
            for (int j = 0; j < colSizes[tracker]; j++)
            {
                results[i][j] = matrices[tracker][i][j];
            }
        }

        return;
    }

    //base case for ONLY two matrix remaining
    if (matrixCount == 2)
    {
        int l = rowSizes[tracker];
        int m = rowSizes[tracker+1];
        int n = colSizes[tracker+1];

        matMul(l, m, n, matrices[tracker], matrices[tracker+1], results); 

        return;
    }

    int split = solutions[tracker + 1][tracker + matrixCount];

    int l = rowSizes[tracker];
    int m = rowSizes[split];
    int n = colSizes[tracker + matrixCount-1];

    int** paper_one = makearray (l, m);

    int** paper_two = makearray (m, n);
    
    // calling for multiplying (left chain)
    multiply(split-tracker, rowSizes, colSizes, matrices, solutions, paper_one, tracker);

    //calling for multiplying (right chain)
    multiply(tracker + matrixCount - split, rowSizes, colSizes, matrices, solutions, paper_two, split);

    matMul(l, m, n, paper_one, paper_two, results); 

    freearray(l, paper_one);
    freearray(m, paper_two);

    return;
}


unsigned int cost 
(
    unsigned int matrixCount,
    unsigned int* rowSizes,
    unsigned int* colSizes
) 
{
    if ( matrixCount==1 ) 
    { // Base case.
        return 0; // No multplication to be done.
    } else 
    {

        unsigned int numPossibleSplits = matrixCount-1; // Think: if there are two matrices to multiply, there is one way to split.
        // AB: (A)(B)
        // ABC: (A)(BC) and (AB)(C)

        unsigned int costs[numPossibleSplits];

        for ( unsigned int split = 0 ; split < numPossibleSplits; split++ ) 
        {

            unsigned int l = rowSizes[0]; // Number of rows in the first matrix
            assert ( colSizes[split] == rowSizes[split+1] );
            unsigned int m = colSizes[split]; // Number of columns in the first matrix, and number of rows in the second matrix
            unsigned int n = colSizes[matrixCount-1]; // Number of columns in the second matrix

            costs[split] =
                cost( split+1, rowSizes, colSizes) + // cost of left subchain
                l * m * n + // cost of multiplying the two chains
                cost( matrixCount-split-1, rowSizes+split+1, colSizes+split+1); // cost of right subchain
        }

        
        unsigned int minCost = costs[0];
        for ( unsigned int split = 1; split < numPossibleSplits; split++ ) 
        {
            if ( costs[split] < minCost ) 
            {
                minCost = costs[split];
                // printf("%d ", minCost);
            }
        }

        return minCost;
    }
}

int main(int argc, char* argv[]) 
{
    unsigned int matrixCount; //number of n matrices "n"
    unsigned int* rowSizes; //records all rows of n matrices 
    unsigned int* colSizes; //records all cols of n matrices
    int*** matrices; // 3D array that holds every single matrices involved in chain

    FILE* fp = fopen(argv[1], "r");
    if (!fp) 
    {
        perror("fopen failed");
        exit(EXIT_FAILURE);
    }

    if (!fscanf(fp, "%d\n", &matrixCount)) 
    {
        perror("reading the number of matrices failed");
        exit(EXIT_FAILURE);
    }

    rowSizes = calloc( matrixCount, sizeof(int) );
    colSizes = calloc( matrixCount, sizeof(int) );
    matrices = calloc( matrixCount, sizeof(int**) );

    for (unsigned int matIndex=0; matIndex<matrixCount; matIndex++) 
    {
        unsigned int rows, cols;

        if (!fscanf(fp, "%d %d\n", &rows, &cols)) 
        {
            perror("reading the dimensions of matrix failed");
            exit(EXIT_FAILURE);
        }

        rowSizes[matIndex] = rows;
        colSizes[matIndex] = cols;

        matrices[matIndex] = calloc( rows, sizeof(int*) );

        for ( unsigned int i=0; i<rows; i++ ) 
        {
            matrices[matIndex][i] = calloc( cols, sizeof(int) );

            for ( unsigned int k=0; k < cols; k++ ) 
            {
                int element;
                if (!fscanf(fp, "%d ", &element)) 
                {
                    perror("reading the element of matrix failed");
                    exit(EXIT_FAILURE);
                }
                matrices[matIndex][i][k] = element;
            }
        }
    }

    int n = matrixCount + 1; //number of matrices in 1 order (NOT 0)

    int parent[n];

    for(int i = 0; i < n-1; i++)
    {
        parent[i] = rowSizes[i];
    }
    parent[n-1] = colSizes[matrixCount-1];

    //parent array filling correctly

    int** totalCost;
    totalCost = makearray(n, n);
    // m 2d array will record the cost of A(BC) and (AB)C it will choose the lower operation cost
    // filled with total operation cost for mutiplying some given matrices
    // A B C

    int** solutions;
    solutions = makearray(n, n);
    // s 2d array will record the optimal splitting points for a given matrix muliplication chain
    // A B C
    // s 2d array will determine optimal splitting point for A B C 
    // i.e: A(BC) is better than (AB)C, s[i][j] will record 1

    int j;
    int minimum;
    int tester;

    for (int difference = 1; difference < n-1; difference++)
    {
        for(int i = 1; i < n-difference; i++)
        {
            j = i + difference;
            minimum = __INT_MAX__;

            for (int k = i; k <= j-1; k++)
            {
                tester = totalCost[i][k] + totalCost[k+1][j] + parent[i-1] * parent[k] * parent[j];

                if (tester < minimum)
                {
                    minimum = tester;
                    solutions[i][j] = k;
                }
            }

            if (tester < totalCost[i][j] || totalCost[i][j] == -1)
            {
                totalCost[i][j] = minimum;
            }
        }
    }

    int** results;
    results = makearray(rowSizes[0], colSizes[matrixCount-1]);    

    //recursive function caller
    multiply(matrixCount, rowSizes, colSizes, matrices, solutions, results, 0);

    //print results
    for (int i = 0; i < rowSizes[0]; i++)
    {
        for (int j = 0; j < colSizes[matrixCount-1]; j++)
        {
            printf("%d ", results[i][j]);
        }
        printf("\n");
    }

    freearray(rowSizes[0], results);
    freearray(n, totalCost);
    freearray(n, solutions);

    for (unsigned int matIndex=0; matIndex<matrixCount; matIndex++) 
    {
        int rows = rowSizes[matIndex];

        for ( unsigned int i=0; i<rows; i++ ) 
        {
            free(matrices[matIndex][i]);
        }

        free(matrices[matIndex]);
    }

    free(matrices);
    free(colSizes);
    free(rowSizes);
    fclose(fp);

    exit(EXIT_SUCCESS);
}
