#include "../graphutils.h"

// A program to find a cycle in a directed graph

// You may use DFS or BFS as needed

int findCycle
(
    size_t graphNodeCount, 
    AdjacencyListNode* adjacencyList, 
    int nodeInput, 
    int* path,
    int pathfinder
)
{    
    path[pathfinder] = nodeInput;
    
    AdjacencyListNode* neighbor = adjacencyList[nodeInput].next;

    while(neighbor != NULL)
    {
        int comparator = neighbor->graphNode;

        //CHECK THIS NEIGHBOR IF THIS NEIGHBOR HAS BEEN VISITED
        for (int i = 0; i <= pathfinder; i++) 
        {
            //IF VISITED, WE FOUND A CYCLE - PRINT OUT THE FIRST ITERATION OF THIS NEIGHBOR
            //AND CONTINUE PRINTING ALL NODES FROM THERE ON UNTIL THIS RECURSION CALL 
            if (path[i] == comparator)
            {
                printf("%d", path[i]);

                for(int j = i + 1; j <= pathfinder; j++)
                {
                    printf(" %d", path[j]);
                }

                printf("\n");

                //WE FOUND A CYCLE, EXIT PROGRAM
                exit(0);
            }
        } 
        
        findCycle(graphNodeCount, adjacencyList, neighbor->graphNode, path, ++pathfinder);

        //IT RAN INTO A DEAD END! PURGE ALL THE RECORDS THAT LEAD TO DEAD END TO PREP FOR NEXT NEIGHBOR IN LINE
        for (int i = pathfinder; i < graphNodeCount*2; i++) 
        {
            path[i] = -1;
        }
        pathfinder--;

        neighbor = neighbor->next;
    }

    //NO CYCLE FOUND, RETURN 0
    return 0;
}


int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;

    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);
    
    int path[graphNodeCount*2];


    int pathfinder = 0;

    for (int i = 0; i < graphNodeCount; i++) 
    {
        path[i] = -1;
    }

    int counter = 0;

    //TO MAKE SURE TO VISIT EVERY NODE, RUN RECURSION FOR EVERY POSSIBLE NODE
    for (int visitingNode = 0; visitingNode < graphNodeCount; visitingNode++) 
    {
        if (findCycle(graphNodeCount, adjacencyList, visitingNode, path, pathfinder) == 0) 
        {
            counter++;
        }
    }

    if (counter > 0)
    {
        printf("DAG\n");
    }

    freeAdjList ( graphNodeCount, adjacencyList );
    return EXIT_SUCCESS;
}