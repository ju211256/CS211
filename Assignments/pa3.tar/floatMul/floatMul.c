#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
// https://www.tutorialspoint.com/c_standard_library/limits_h.htm
#include <limits.h>
// https://www.cplusplus.com/reference/cfloat/
#include <float.h>

#define FLOAT_SZ sizeof(float)*CHAR_BIT
#define EXP_SZ (FLOAT_SZ-FLT_MANT_DIG)
#define FRAC_SZ (FLT_MANT_DIG-1)

int main(int argc, char *argv[]) 
{
    // float value = *(float *) &binary; // you are not allowed to do this.
    // unsigned int binary = *(unsigned int*) &value; // you are not allowed to do this.

    FILE* fp = fopen(argv[1], "r");
    if (!fp) 
    {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the binary number representation of multiplier
    char buff;
    unsigned int multiplier = 0;

    for (int i=EXP_SZ+FRAC_SZ; 0<=i; i--) 
    { 
        // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);

        multiplier = multiplier << 1 | (buff - 48);
    }

    // float number = *(float *)&binary; // you are not allowed to do this.
    int negate = ~( 1 << (EXP_SZ + FRAC_SZ) );

    // Sign
    bool multiplier_sign = multiplier >> ( EXP_SZ + FRAC_SZ ) & 1;
    multiplier = multiplier & negate;

    // Exponent
    int multiplier_exponent = multiplier >> FRAC_SZ & ( (1 << EXP_SZ) - 1 );
    multiplier = multiplier & negate;

    // Mantissa
    double multiplier_mantissa = multiplier & ( (1 << FRAC_SZ) - 1 );
    multiplier_mantissa = ( multiplier_mantissa / pow(2, FRAC_SZ) ) + 1.0;


    // notice that you are reading two different lines; caution with reading
    /* ... */
    fscanf(fp, "\n"); 

    // first, read the binary number representation of multiplcand
    unsigned int multiplicand = 0;

    for (int i=EXP_SZ+FRAC_SZ; 0<=i; i--) 
    { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);

        multiplicand = multiplicand << 1 | (buff - 48);
    }

    // float number = *(float *)&binary; // you are not allowed to do this.

    // Sign
    bool multiplicand_sign = multiplicand >> ( EXP_SZ + FRAC_SZ ) & 1;
    multiplicand = multiplicand & negate;

    // Exponent
    int multiplicand_exponent = multiplicand >> FRAC_SZ & ( (1 << EXP_SZ) - 1 );
    multiplicand = multiplicand & negate;

    // Mantissa
    double multiplicand_mantissa = multiplicand & ( (1 << FRAC_SZ) - 1 );
    multiplicand_mantissa = ( multiplicand_mantissa / pow(2, FRAC_SZ) ) + 1.0;


    // float product = *(float *) &multiplier * *(float *) &multiplicand; // you are not allowed to print from this.
    // unsigned int ref_bits = *(unsigned int *) &product; // you are not allowed to print from this. But you can use it to validate your solution.

    // SIGN
    /* ... */
    bool sign = false;

    if (multiplier_sign && multiplicand_sign)
    {
        sign = false;

    } else if (multiplier_sign | multiplicand_sign)
    {
        sign = true;
    }

    printf("%d_",sign);
    // assert (sign == (1&ref_bits>>(EXP_SZ+FRAC_SZ)));

    // EXP

    // get the exp field of the multiplier and multiplicand
    /* ... */

    // add the two exp together
    int exponent = multiplier_exponent + multiplicand_exponent;
    // subtract bias
    unsigned short bias = (1<<(EXP_SZ-1))-1;
    exponent = exponent - bias;

    // FRAC

    // get the frac field of the multiplier and multiplicand
    /* ... */

    // assuming that the input numbers are normalized floating point numbers, add back the implied leading 1 in the mantissa
    /* ... */

    // multiply the mantissas
    double fraction = multiplier_mantissa * multiplicand_mantissa;

    // overflow and normalize
    /* ... */
    if (fraction >= 2) 
    {
        while(true)
        {
            if (fraction < 2)
            {
                break;
            }

            fraction = fraction / 2;
            exponent = exponent + 1;
        
        }

    } 
    

    // rounding
    /* ... */

    // move decimal point
    /* ... */

    // PRINTING

    // print exp
    for ( int bit_index=EXP_SZ-1; 0<=bit_index; bit_index-- ) 
    {
        bool trial_bit = 1&exponent>>bit_index;
        printf("%d",trial_bit);
        // assert (trial_bit == (1&ref_bits>>(bit_index+FRAC_SZ)));
    }
    printf("_");

    bool frac_array[FRAC_SZ+1]; // one extra LSB bit for rounding

    for ( int frac_index=FRAC_SZ; 0<=frac_index; frac_index-- ) 
    {            
        fraction = 2 * (fraction - (unsigned short) fraction);

        if(fraction >= 1) 
        {
            frac_array[frac_index] = true; 
            fraction = fraction - (long) fraction;
        } else 
        {
            frac_array[frac_index] = false; 
            fraction = fraction - (unsigned short) fraction;
        }

    }

    // fix the carry over error in the fraction via binary addition logic
    bool carry = true; 
    for (int frac_index=0; frac_index<FRAC_SZ; frac_index++) 
    { 
        bool temp = frac_array[frac_index];

        frac_array[frac_index] = temp ^ carry; // bitwise XOR operation
        carry = temp & carry; // bitwise AND operation 
    }

    //print frac
    for ( int frac_index=FRAC_SZ-1; 0<=frac_index; frac_index-- ) 
    {
        bool frac_bit = frac_array[frac_index+1]; // skipping the extra LSB bit for rounding
        printf("%d", frac_bit);
        // assert (frac_bit == (1&ref_bits>>frac_index)); // validate your result against the reference
    }

    return(EXIT_SUCCESS);

}
