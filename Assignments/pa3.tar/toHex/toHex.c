#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
    FILE* fp = fopen(argv[1], "r");
    if (!fp) 
    {
        perror("fopen failed");
        return 0;
    }

    // first, read the number
    signed int input;
    fscanf(fp, "%d\n", &input);

    // convert to hexadecimal
    char hex[9];
    int bit_index = 0;

    for (int bit = 7; bit >= 0; bit--) 
    {
        int bits_val = input >> bit*4 & 0xF; // shift and mask, access 4 bit at a time

        char hex_char;

        if (bits_val < 10)
        {
            hex_char = bits_val + '0';
        } else
        {
            hex_char = bits_val - 10 + 'A';
        }

        hex[bit_index] = hex_char;
        bit_index += 1;
    }

    hex[8] = '\0'; // cut off array here, do not use it anymore beyond this point

    // print only the last 4 digits
    printf("%s\n", &hex[4]);

    return EXIT_SUCCESS;
}
